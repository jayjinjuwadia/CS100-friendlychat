package com.google.firebase.udacity.friendlychat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class groupchat extends MainActivity {
    private Button butt;
    private FirebaseDatabase mData;
    private DatabaseReference mStor;
    private ListView lview;
    private Groupchatadapter mGroupAdapter;
    protected ArrayList<groupchatname> gcarray = new ArrayList<groupchatname>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grouplist);
        Button butt = (Button) findViewById(R.id.creategroupbutton);
        mData = FirebaseDatabase.getInstance();

        butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = "Group Chat ";
                String b = String.valueOf(gcarray.size());
                a = a.concat(b);
                groupchatname gca = new groupchatname(a, 0, null);
                gcarray.add(gca);
                mStor = FirebaseDatabase.getInstance().getReference().child(gcarray.get(gcarray.size() - 1).getChatname());
                FriendlyMessage msg = new FriendlyMessage("Welcome to the chat!",FirebaseAuth.getInstance().getCurrentUser().getDisplayName(), "");
               mStor.push().setValue(msg);
                mGroupAdapter = new Groupchatadapter(groupchat.this, gcarray);
                lview.setAdapter(mGroupAdapter);

            }
        });

    }

}